"""Core application modules (config, database, security)."""
